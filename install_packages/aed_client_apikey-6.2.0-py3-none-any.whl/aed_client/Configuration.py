import json
from aed_client import AEDService

PATH_FORMAT_CFG_GET_VALUE = '/settings/{0}/{1}'
PATH_FORMAT_CFG_GET_VALUES = '/settings/{0}'
PATH_FORMAT_CFG_GET_FILE = '/configuration/{0}?file={1}'
HTTP_CONTENT_TYPE_JSON = 'application/json'
 
class Configuration():
    def get_value(self, module, key):
        url = PATH_FORMAT_CFG_GET_VALUE.format(module, key)
        pair = json.loads(AEDService().get(HTTP_CONTENT_TYPE_JSON, url).content.decode())
        return pair[key]

    def get_values(self, module):
        url = PATH_FORMAT_CFG_GET_VALUES.format(module)
        return json.loads(AEDService().get(HTTP_CONTENT_TYPE_JSON, url).content.decode())

    # Assumes json only in this case, but technically, wont stop for allowing other file types
    def get_file(self, module, file):        
        url = PATH_FORMAT_CFG_GET_FILE.format(module, file)
        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url).content.decode()
