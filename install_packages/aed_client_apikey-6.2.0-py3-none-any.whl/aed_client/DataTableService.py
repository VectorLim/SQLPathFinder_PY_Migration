import json
from aed_client import AEDService

PATH_FORMAT_TABLE_SVC = '/datatables/{0}/{1}'
HTTP_CONTENT_TYPE_JSON = 'application/json'

class DataTableService():
    def get(self, category, name):
        url = PATH_FORMAT_TABLE_SVC.format(category, name)
        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url)

    def overwrite(self, category, name, datatable):
        url = PATH_FORMAT_TABLE_SVC.format(category, name)
        content = json.dumps(datatable, indent = 4) 

        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url, content)

    def merge(self, category, name, datatable):
        url = PATH_FORMAT_TABLE_SVC.format(category, name)
        content = json.dumps(datatable, indent = 4) 

        return AEDService().patch(HTTP_CONTENT_TYPE_JSON, url, content)
