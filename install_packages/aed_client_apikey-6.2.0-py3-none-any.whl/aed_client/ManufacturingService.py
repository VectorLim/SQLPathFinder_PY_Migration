from aed_client import AEDService

PATH_FORMAT_MFG_SYS_LOT_HOLD = '/manufacturing/lots/{0}/hold?operation={1}&holdcode={2}&comment={3}'
PATH_FORMAT_MFG_SYS_LOT_MOVE_IN = '/manufacturing/lots/{0}/move-in?operation={1}'
PATH_FORMAT_MFG_SYS_LOT_MOVE_OUT = '/manufacturing/lots/{0}/move-out?operation={1}&quantity={2}'
PATH_FORMAT_MFG_SYS_LOT_MOVE_RELEASE = '/manufacturing/lots/{0}/release?operation={1}&comment={2}'
PATH_FORMAT_MFG_SYS_LOT_STATUS = '/manufacturing/lots/{0}'
PATH_FORMAT_MFG_SYS_LOT_CONTAIN = '/manufacturing/lots/{0}/contain?operation={1}&referenceNumber={2}'
PATH_FORMAT_MFG_SYS_LOT_UNCONTAIN = '/manufacturing/lots/{0}/uncontain?operation={1}&referenceNumber={2}&comment={3}'
PATH_FORMAT_MFG_SYS_ENTITY_DOWN = '/manufacturing/entities/{0}/tooldown?module={1}&componentId={2}&description={3}'
PATH_FORMAT_MFG_SYS_SET_LOT_ATTR = '/manufacturing/lots/{0}/attributes/{1}?attributevalue={2}'
PATH_FORMAT_MFG_SYS_GET_LOT_ATTR = '/manufacturing/lots/{0}/attributes/{1}'
PATH_FORMAT_MFG_SYS_CONTAIN_LOTS = '/manufacturing/lots/contain?commaseparatedlotlist={0}&referenceNumber={1}&disposition={2}&commaseparatedoperationslist={3}&emaillist={4}&starttraceoperation={5}'
PATH_FORMAT_MFG_SYS_GET_TESTER_TRACED_LOTS = '/manufacturing/lots/{0}/trace/tester/{1}?tiuId={2}&thermalHeadId={3}&forwardOffset={4}&backwardOffset={5}'

HTTP_CONTENT_TYPE_JSON = 'application/json'


class ManufacturingService():   
    def lot_hold(self, lotid, operation, holdcode, comment):
        url = PATH_FORMAT_MFG_SYS_LOT_HOLD.format(lotid, operation, holdcode, comment)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)

    def lot_move_in(self, lotid, operation):
        url = PATH_FORMAT_MFG_SYS_LOT_MOVE_IN.format(lotid, operation)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)
    
    def lot_move_out(self, lotid, operation, quantity):
        url = PATH_FORMAT_MFG_SYS_LOT_MOVE_OUT.format(lotid, operation, quantity)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)
    
    def lot_release(self, lotid, operation, comment):
        url = PATH_FORMAT_MFG_SYS_LOT_MOVE_RELEASE.format(lotid, operation, comment)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)
    
    def lot_status(self, lotid):
        url = PATH_FORMAT_MFG_SYS_LOT_STATUS.format(lotid)
        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url)

    def lot_contain(self, lotid, operation, reference_number):
        url = PATH_FORMAT_MFG_SYS_LOT_CONTAIN.format(lotid, operation, reference_number)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)
        
    def lot_uncontain(self, lotid, operation, reference_number, comment):
        url = PATH_FORMAT_MFG_SYS_LOT_UNCONTAIN.format(lotid, operation, reference_number, comment)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)

    def entity_down(self, entity, module, componentid, description):
        url = PATH_FORMAT_MFG_SYS_ENTITY_DOWN.format(entity, module, componentid, description)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)
    
    def lot_set_attr(self, lotid, attributeid, attributevalue):
        url = PATH_FORMAT_MFG_SYS_SET_LOT_ATTR.format(lotid, attributeid, attributevalue)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)

    def lot_get_attr(self, lotid, attributeid):
        url = PATH_FORMAT_MFG_SYS_GET_LOT_ATTR.format(lotid, attributeid)
        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url)
    
    def contain_lots(self, commaseparatedlotlist, reference_number, disposition, commaseparatedoperationslist, emaillist, starttraceoperation):
        url = PATH_FORMAT_MFG_SYS_CONTAIN_LOTS.format(commaseparatedlotlist, reference_number, disposition, commaseparatedoperationslist, emaillist, starttraceoperation)
        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url)
    
    def get_tester_traced_lots(self, lotid, tester_id, tiu_id, thermal_id, forward_offset, backward_offset):
        url = PATH_FORMAT_MFG_SYS_GET_TESTER_TRACED_LOTS.format(lotid, tester_id, tiu_id, thermal_id, forward_offset, backward_offset)
        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url)

