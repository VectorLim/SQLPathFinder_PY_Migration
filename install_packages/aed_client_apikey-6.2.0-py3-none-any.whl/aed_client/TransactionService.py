import aed_client
from aed_client import AEDService

PATH_FORMAT_TRANSACTION_SVC = '/transactions/{0}/{1}'
HTTP_CONTENT_TYPE_JSON = 'application/json'

class TransactionService():    
    def get(self, path):
        transactionid = aed_client.transaction_id
        url = PATH_FORMAT_TRANSACTION_SVC.format(transactionid, path)
        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url)        
    
    def get_context(self):
        return self.get('context')
    
    def get_logs(self):
        return self.get('logs')