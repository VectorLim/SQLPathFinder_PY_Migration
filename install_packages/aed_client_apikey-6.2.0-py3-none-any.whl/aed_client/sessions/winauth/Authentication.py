import requests
# windows auth packages
import ssl
from requests_auth import NTLM
from requests.adapters import HTTPAdapter

class SSLContextAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.SSLContext(ssl.PROTOCOL_TLS) 
        kwargs['ssl_context'] = context        
        context.load_default_certs() # this loads the OS defaults on Windows
        return super(SSLContextAdapter, self).init_poolmanager(*args, **kwargs)

class Authentication():
    def __init__(self, is_debug = None):
        self.is_debug = is_debug

    def create_session(self, accepts, transaction_id, transaction_context = None):
        session = requests.Session()
        adapter = SSLContextAdapter()
        for prefix in "http://", "https://":
            session.mount(prefix, adapter)

        # allows for local debugging calls to execute without cert check
        session.verify = not self.is_debug
        session.auth=NTLM()
        session.headers.update({"Accept" : accepts})
        session.headers.update({"TransactionId" : transaction_id})
        if transaction_context:
            session.headers.update({"TransactionContext" : transaction_context})
        
        return session

