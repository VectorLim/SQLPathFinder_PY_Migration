from pathlib import Path
import requests
import os

# Generate .crt file from:
# http://certificates.intel.com/repository/certificates/IntelSHA256RootCA-Base64.crt

class Authentication():
    def __init__(self, is_debug = None):
        self.is_debug = is_debug

    def create_session(self, accepts, transaction_id, transaction_context = None):
        x_api_key_str = os.environ["X_API_KEY"]
        file = './IntelSHA256RootCA-Base64.crt'

        if not x_api_key_str:
            print("Unable to find environment variable: X_API_KEY")            

        if not Path(file).is_file():
            print("Unable to find certificate file: " + file)            

        session = requests.Session()
        session.headers.update({'X-API-Key': x_api_key_str})
        session.verify = './IntelSHA256RootCA-Base64.crt'
        session.headers.update({"Accept" : accepts})
        session.headers.update({"TransactionId" : transaction_id})
        if transaction_context:
            session.headers.update({"TransactionContext" : transaction_context})
        
        return session
