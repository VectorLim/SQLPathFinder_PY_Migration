from aed_client import AEDService


PATH_FORMAT_NOTIFICATIONS_SVC = '/notifications/{0}/send?subject={1}&to={2}&cc={3}'
HTTP_CONTENT_TYPE_TEXT = 'text/plain'

class NotificationsService():
    def sendmail(self, template, to, cc, subject, body):
        #this is a hack for cc coming as empty array
        if not cc:
            cc = ""

        url = PATH_FORMAT_NOTIFICATIONS_SVC.format(template, subject, to, cc)    
        #content = json.dumps(body, indent = 4)     
        return AEDService().post(HTTP_CONTENT_TYPE_TEXT, url, body)