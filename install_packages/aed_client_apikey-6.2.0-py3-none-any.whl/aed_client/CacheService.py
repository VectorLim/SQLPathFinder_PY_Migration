from aed_client import AEDService

PATH_FORMAT_CACHE_SVC = '/cache/{0}?cacheName={1}}'
HTTP_CONTENT_TYPE_JSON = 'application/json'
 
class CacheService():
    def get(self, category, name, key=""):
        url = PATH_FORMAT_CACHE_SVC.format(category, name)
        if key:
            url = url +"&cacheKey=" + key

        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url)