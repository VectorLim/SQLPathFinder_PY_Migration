import base64
import winreg
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

class Cryptography():
    def _get_key(self):
        access_registry = winreg.ConnectRegistry(None,winreg.HKEY_LOCAL_MACHINE)
        access_key = winreg.OpenKey(access_registry,r"SOFTWARE\Wow6432Node\Intel\AED")
        value = winreg.QueryValueEx(access_key,"DecryptionKey")

        if access_key:            
            password = value[0].encode()
            hkdf = HKDF(
                algorithm=hashes.SHA256(), 
                length=32,
                salt=None,   
                info=None,   
                backend=default_backend()
            )
            return base64.urlsafe_b64encode(hkdf.derive(password))
        else:
            raise Exception("No encryption key configured on system")

    def encrypt(self, data):
        fernet = Fernet(self._get_key())       
        return fernet.encrypt(data.encode()).decode()

    def decrypt(self, data):
        fernet = Fernet(self._get_key())       
        return fernet.decrypt(data.encode()).decode()
