import json
from aed_client import AEDService
import aed_client

PATH_FORMAT_DATA_SVC = '/datastreams/{0}?stream={1}'
PATH_FORMAT_DATA_CACHE_SVC = '/datastreams/cache/{0}/{1}?stream={2}'
HTTP_CONTENT_TYPE_JSON = 'application/json'

class DataService():    
    def get(self, module, stream, query_parameters):
        url = PATH_FORMAT_DATA_SVC.format(module, stream)

        content = json.dumps(query_parameters, indent = 4) 

        if aed_client.override_factory:
            url = url + '&factoryOverride=' + aed_client.override_factory

        return AEDService().post(HTTP_CONTENT_TYPE_JSON, url, content)
    
    def cache_add(self, module, target, stream, query_parameters):
        #qs = urlencode(query_parameters)
        url = PATH_FORMAT_DATA_CACHE_SVC.format(module, target, stream)

        if aed_client.override_factory:
            url = url + '&factoryOverride=' + aed_client.override_factory
     
        content = json.dumps(query_parameters, indent = 4) 

        return AEDService().put(HTTP_CONTENT_TYPE_JSON, url, content)

    def cache_get(self, module, target, stream):
        url = PATH_FORMAT_DATA_CACHE_SVC.format(module, target, stream)
        return AEDService().get(HTTP_CONTENT_TYPE_JSON, url)

    def cache_delete(self, module, target, stream):
        url = PATH_FORMAT_DATA_CACHE_SVC.format(module, target, stream)
        return AEDService().delete(HTTP_CONTENT_TYPE_JSON, url)

