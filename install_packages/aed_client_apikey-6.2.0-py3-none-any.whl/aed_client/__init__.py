import os
import argparse

parser=argparse.ArgumentParser(description='ATM eDispo Python Client')
parser.add_argument('-t', '--transaction', dest='transaction_id', action='store', help='ATM eDispo transaction id')
parser.add_argument('-e','--env', dest='environment', action='store', help='Environment name (PROD, ITE, UAT_VNEXT, TEST_VNEXT, ITE_VNEXT)')
parser.add_argument('-f', '--facility', dest='facility', action='store', help='Facility name')
parser.add_argument('-p', '--protocol', dest='protocol', action='store', default='https', help='Service protocal (http, https)')
parser.add_argument('-c', '--cachepath', dest='cache_path', action='store', help='Local path for cache file storage')
parser.add_argument('-o', '--override', dest='override_factory', action='store', help='Override factory name')
parser.add_argument('-ctx', '--context', dest='transaction_context', action='store', help='Transaction Context')
parser.add_argument('-l', '--lot', dest='lot_id', action='store', help='Transaction Lot id')
parser.add_argument('-fo', '--from_oper', dest='from_oper', action='store', help='Transaction from operation')
parser.add_argument('-to', '--to_oper', dest='to_oper', action='store', help='Transaction to operation')
parser.add_argument('-d', '--debug', dest='is_debug', action='store_true', help='Enable debug mode (disables cert checks, and routes to local services)', default=False)
parser.add_argument('-cp', '--configpath', dest='config_path', action='store', help='Path for config files')
parser.add_argument('-pg3', '--prodgroup3', dest='prodgroup3', action='store', help='prodgroup3 for the lot')
parser.add_argument('-dc', '--diecodename', dest='diecodename', action='store', help='diecodename for the lot')
parser.add_argument('-hc', '--holdcategory', dest='holdcategory', action='store', help='hold category for the lot')
parser.add_argument('-hf', '--holdflag', dest='holdflag', action='store', help='hold flag for the lot')
parser.add_argument('-hn', '--holdname', dest='holdname', action='store', help='hold name for the lot')
parser.add_argument('-r', '--routeid', dest='routeid', action='store', help='routeid for the lot')
parser.add_argument('-scr', '--screen', dest='screen_name', action='store', help='screen name')
parser.add_argument('-qty', '--quantity', dest='quantity', action='store', help='quantity in the lot')
parser.add_argument('-rops', '--routeops', dest='currentrouteoperations', action='store', help='operations in the route')
parser.add_argument('-pid', '--productid', dest='productid', action='store', help='product id')
parser.add_argument('-own', '--owner', dest='owner', action='store', help='Owner')
parser.add_argument('-mt', '--moveouttransaction', dest='moveouttransaction', action='store', help='Move out transaction')
parser.add_argument('-mrb1', '--mrbnumber1', dest='mrbnumber1', action='store', help='MRBNumber1')
parser.add_argument('-mrb2', '--mrbnumber2', dest='mrbnumber2', action='store', help='MRBNumber2')
parser.add_argument('-mrb3', '--mrbnumber3', dest='mrbnumber3', action='store', help='MRBNumber3')
parser.add_argument('-sf1', '--shippableflag1', dest='shippableflag1', action='store', help='ShippableFlag1')
parser.add_argument('-sf2', '--shippableflag2', dest='shippableflag2', action='store', help='ShippableFlag2')
parser.add_argument('-sf3', '--shippableflag3', dest='shippableflag3', action='store', help='ShippableFlag3')
parser.add_argument('-rf', '--reworkedflag', dest='reworkedflag', action='store', help='Reworked Flag')
parser.add_argument('-mf', '--moveinflag', dest='moveinflag', action='store', help='Move in flag')
parser.add_argument('-plid', '--parentlotid', dest='parentlotid', action='store', help='Parent Lot Id')
parser.add_argument('-md', '--moveOutDateTime', dest='moveoutdatetime', action='store', help='Move out date time')
parser.add_argument('-tt', '--triggerTransaction', dest='triggerTransaction', action='store', help='Trigger Transaction')
args=parser.parse_args()


transaction_id = args.transaction_id
environment = args.environment
facility = args.facility
protocol = args.protocol or "HTTPS"
cache_path = args.cache_path
override_factory = args.override_factory
is_debug = args.is_debug
transaction_context = args.transaction_context
lot_id = args.lot_id
from_operation = args.from_oper
to_operation = args.to_oper
config_path = args.config_path
prodgroup3 = args.prodgroup3
diecodename = args.diecodename
holdcategory = args.holdcategory
holdflag = args.holdflag
holdname = args.holdname
routeid = args.routeid
screen_name = args.screen_name
quantity=args.quantity
currentrouteoperations=args.currentrouteoperations
productid=args.productid
owner=args.owner
moveouttransaction=args.moveouttransaction
mrbnumber1=args.mrbnumber1
mrbnumber2=args.mrbnumber2
mrbnumber3=args.mrbnumber3
shippableflag1=args.shippableflag1
shippableflag2=args.shippableflag2
shippableflag3=args.shippableflag3
reworkedflag=args.reworkedflag
moveinflag=args.moveinflag
parentlotid=args.parentlotid
moveoutdatetime=args.moveoutdatetime
triggerTransaction=args.triggerTransaction

from .AEDService import *
from .CacheService import *
from .Configuration import *
from .DataService import *
from .DataTableService import *
from .ManufacturingService import *
from .TransactionService import *
from .NotificationsService import *

if os.name == 'nt':
    from .Cryptography import *

def load_context(header : str):

    if header:
        context = json.loads(header)
        j_properties = context["properties"]
        properties = {}
        for item in j_properties:
            properties[item['name']] = item['value']
        
        if len(properties) > 0:
            aed_client.transaction_id = properties.get('transaction')
            aed_client.environment = properties.get('env')
            aed_client.facility = properties.get('facility')
            aed_client.protocol = properties.get('protocol') or "HTTPS"
            aed_client.cache_path = properties.get('cachepath')
            aed_client.override_factory = properties.get('override')
            aed_client.is_debug = properties.get('debug')
            aed_client.transaction_context = properties.get('context')
            aed_client.lot_id = properties.get('lot')
            aed_client.from_operation = properties.get('from_oper')
            aed_client.to_operation = properties.get('to_oper')
            aed_client.config_path = properties.get('configpath')
            aed_client.prodgroup3 = properties.get('prodgroup3')
            aed_client.diecodename = properties.get('diecodename')
            aed_client.holdcategory = properties.get('holdcategory')
            aed_client.holdflag = properties.get('holdflag')
            aed_client.holdname = properties.get('holdname')
            aed_client.routeid = properties.get('routeid')
            aed_client.screen_name = properties.get('screen_name')
            aed_client.quantity = properties.get('quantity')
            aed_client.currentrouteoperations = properties.get('currentrouteoperations')
            aed_client.routeops = properties.get('routeops')
            aed_client.productid = properties.get('productid')
            aed_client.owner = properties.get('owner')
            aed_client.moveouttransaction = properties.get('moveouttransaction')
            aed_client.mrbnumber1 = properties.get('mrbnumber1')
            aed_client.mrbnumber2 = properties.get('mrbnumber2')
            aed_client.mrbnumber3 = properties.get('mrbnumber3')
            aed_client.shippableflag1 = properties.get('shippableflag1')
            aed_client.shippableflag2 = properties.get('shippableflag2')
            aed_client.shippableflag3 = properties.get('shippableflag3')
            aed_client.reworkedflag = properties.get('reworkedflag')
            aed_client.moveinflag = properties.get('moveinflag')
            aed_client.parentlotid = properties.get('parentlotid')
            aed_client.moveoutdatetime = properties.get('moveOutDateTime')
            aed_client.triggerTransaction = properties.get('triggerTransaction')
    
