
import aed_client

try:
    from .sessions.apikey.Authentication import Authentication
except ModuleNotFoundError:
    from .sessions.winauth.Authentication import Authentication


DEBUG_FLAG = "DEBUG"
PROTOCOL_HTTP = "http"
PROTOCOL_HTTPS = "https"
PATH_FORMAT_DOMAIN = '{0}://{1}-{2}.atmedispo.intel.com/{3}'
PATH_REST_VERSION = 'api/latest'

class AEDService():
    def __init__(self):
        self.environment = aed_client.environment
        self.facility = aed_client.facility
        self.transaction_id = aed_client.transaction_id
        self.protocol = aed_client.protocol
        self.is_debug = aed_client.is_debug
        self.cache_path = aed_client.cache_path
        self.override_factory = aed_client.override_factory
        self.transaction_context = aed_client.transaction_context
        self.config_path = aed_client.config_path

        if self.is_debug:
            print('DEBUG MODE ENABLED')

        if self.override_factory:
            print("Using factory override: " + self.override_factory)

    def _get_service_base_path(self):
        if self.is_debug:
            if self.protocol.lower() == PROTOCOL_HTTPS :
                print('Routing calls to local debug environment')
                return 'https://localhost:44362/' + PATH_REST_VERSION
            else :
                return 'http://localhost:41327/' + PATH_REST_VERSION
        
        return PATH_FORMAT_DOMAIN.format(self.protocol, self.facility, self.environment, PATH_REST_VERSION)
    
    def send(self, method, relative_url, content):
        fullpath = self.get_path(relative_url)
        print('Contacting: ' + fullpath)       
        response = method(url=fullpath, data=content) 
        print('Response code: ' + repr(response.status_code))
        return response

    def get(self, accepts, relative_url):
        session = Authentication(self.is_debug).create_session(accepts, self.transaction_id, self.transaction_context).get
        return self.send(session, relative_url, "")         

    def post(self, accepts, relative_url, content = None):
        print(self.is_debug)
        print(accepts)
        print(self.transaction_id)
        print(self.transaction_context)
        session = Authentication(self.is_debug).create_session(accepts, self.transaction_id, self.transaction_context).post
        return self.send(session, relative_url, content)    

    def put(self, accepts, relative_url, content = None):
        return self.send(Authentication(self.is_debug).create_session(accepts, self.transaction_id, self.transaction_context).put, relative_url, content)                

    def delete(self, accepts, relative_url, content = None):
        return self.send(Authentication(self.is_debug).create_session(accepts, self.transaction_id, self.transaction_context).delete, relative_url, content)                
                        
    def patch(self, accepts, relative_url, content = None):
        session = Authentication(self.is_debug).create_session(accepts, self.transaction_id, self.transaction_context).patch
        return self.send(session, relative_url, content)         

    def get_path(self, relative_url):
        return self._get_service_base_path() + relative_url
